import Foundation

// MARK: - Request

struct DetectionRequest: Encodable {
    let text: String
    let version: String = "v1"
}

// MARK: - API Response (matches actual JSON structure)

struct APIResponse: Decodable {
    let success: Bool
    let data: APIData
}

struct APIData: Decodable {
    let details: APIDetails
}

struct APIDetails: Decodable {
    let chunks: [APIChunk]
    let aiPercentage: Double

    enum CodingKeys: String, CodingKey {
        case chunks
        case aiPercentage = "ai_percentage"
    }
}

struct APIChunk: Decodable {
    let text: String
    let type: String
    let score: Double
}

// Convenience wrapper used by the ViewModel
struct DetectionResponse {
    let aiPercentage: Double
    let humanPercentage: Double
    let mixedPercentage: Double

    init(from api: APIResponse) {
        self.aiPercentage = api.data.details.aiPercentage

        // Derive human/mixed from chunk scores
        let chunks = api.data.details.chunks
        let totalChunks = Double(max(chunks.count, 1))
        let aiChunks = chunks.filter { $0.type == "AI" }
        let humanChunks = chunks.filter { $0.type == "Human" || $0.type == "human" }

        let aiPct = self.aiPercentage
        let humanPct = Double(humanChunks.count) / totalChunks * 100.0
        self.humanPercentage = humanPct > 0 ? humanPct : max(0, (100.0 - aiPct) * 0.6)
        self.mixedPercentage = max(0, 100.0 - aiPct - self.humanPercentage)
    }
}

// MARK: - Detection Result (View-friendly)

struct DetectionResult {
    let aiPercentage: Int
    let humanPercentage: Int
    let mixedPercentage: Int

    var isLikelyAI: Bool { aiPercentage > 50 }

    var label: String {
        isLikelyAI ? "Text is likely AI-Generated" : "Text is likely Human-Written"
    }

    var summary: String {
        "There is a \(aiPercentage)% probability this text was written by AI"
    }

    init(from response: DetectionResponse) {
        self.aiPercentage = Int(response.aiPercentage.rounded())
        // Derive human/mixed if API doesn't return them
        if response.humanPercentage == 0 && response.mixedPercentage == 0 {
            let remaining = 100 - self.aiPercentage
            self.humanPercentage = max(0, remaining * 2 / 3)
            self.mixedPercentage = max(0, remaining - self.humanPercentage)
        } else {
            self.humanPercentage = Int(response.humanPercentage.rounded())
            self.mixedPercentage = Int(response.mixedPercentage.rounded())
        }
    }
}
