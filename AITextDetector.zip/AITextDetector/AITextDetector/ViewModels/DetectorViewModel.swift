import SwiftUI

@MainActor
final class DetectorViewModel: ObservableObject {

    // MARK: - Published State

    @Published var inputText: String = ""
    @Published var isLoading: Bool = false
    @Published var result: DetectionResult?
    @Published var errorMessage: String?
    @Published var showResults: Bool = false

    // MARK: - Computed

    var isInputEmpty: Bool { inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var characterCount: Int { inputText.count }

    // MARK: - Dependencies

    private let service: DetectionServiceProtocol

    init(service: DetectionServiceProtocol = DetectionService()) {
        self.service = service
    }

    // MARK: - Actions

    func detectAI() {
        guard !isInputEmpty else { return }

        triggerHaptic()
        isLoading = true
        errorMessage = nil

        Task {
            do {
                let response = try await service.detectAI(text: inputText)
                self.result = DetectionResult(from: response)
                FirebaseConfig.logDetection(aiPercentage: self.result?.aiPercentage ?? 0)
                withAnimation(.easeInOut(duration: 0.4)) {
                    self.showResults = true
                }
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isLoading = false
        }
    }

    func clearText() {
        triggerHaptic()
        inputText = ""
        result = nil
        errorMessage = nil
        showResults = false
    }

    func dismissResults() {
        withAnimation(.easeInOut(duration: 0.3)) {
            showResults = false
        }
    }

    // MARK: - Haptics

    private func triggerHaptic() {
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()
    }
}
