import Foundation

enum APIConfig {
    static let baseURL = "https://api.detecting-ai.com/api/detect/"

    // Replace with your actual API key
    static var apiKey: String {
        guard let key = Bundle.main.object(forInfoDictionaryKey: "AI_DETECTOR_API_KEY") as? String,
              !key.isEmpty else {
            return "d635bcbb1fde650914edb7f03605655e4269b6878356814982deae3504d4083a"
        }
        return key
    }
}
