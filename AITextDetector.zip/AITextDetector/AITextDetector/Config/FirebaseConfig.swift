import Foundation
import FirebaseCore
import FirebaseAnalytics

/// Central Firebase configuration.
/// Call `FirebaseConfig.configure()` once at app launch.
enum FirebaseConfig {

    static func configure() {
        FirebaseApp.configure()
        Analytics.setAnalyticsCollectionEnabled(true)
    }

    // MARK: - Analytics Events

    static func logEvent(_ name: String, parameters: [String: Any]? = nil) {
        Analytics.logEvent(name, parameters: parameters)
    }

    static func logScreenView(_ screenName: String) {
        Analytics.logEvent(AnalyticsEventScreenView, parameters: [
            AnalyticsParameterScreenName: screenName
        ])
    }

    static func logDetection(aiPercentage: Int) {
        Analytics.logEvent("ai_detection", parameters: [
            "ai_percentage": aiPercentage,
            "is_likely_ai": aiPercentage > 50
        ])
    }

    static func logProTapped(source: String) {
        Analytics.logEvent("go_pro_tapped", parameters: [
            "source": source
        ])
    }

    static func logPurchaseCompleted(productId: String) {
        Analytics.logEvent("purchase_completed", parameters: [
            "product_id": productId
        ])
    }
}
