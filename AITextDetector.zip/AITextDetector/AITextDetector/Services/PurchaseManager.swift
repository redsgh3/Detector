import Foundation
import RevenueCat
import SwiftUI

/// RevenueCat configuration constants.
/// Replace these with your actual RevenueCat identifiers.
enum PurchaseConstants {
    static let apiKey = "YOUR_REVENUECAT_API_KEY"
    static let proEntitlementID = "pro"
    static let proWeeklyID = "pro_weekly"
    static let proMonthlyID = "pro_monthly"
    static let proYearlyID = "pro_yearly"
}

// MARK: - Purchase Manager

@MainActor
final class PurchaseManager: NSObject, ObservableObject {

    static let shared = PurchaseManager()

    // MARK: - Published State

    @Published private(set) var isProUser: Bool = false
    @Published private(set) var offerings: Offerings?
    @Published private(set) var currentOffering: Offering?
    @Published private(set) var isPurchasing: Bool = false
    @Published private(set) var isRestoring: Bool = false
    @Published var errorMessage: String?

    // MARK: - Init

    private override init() {
        super.init()
    }

    // MARK: - Configure (call once at app launch)

    func configure() {
        Purchases.logLevel = .debug
        Purchases.configure(withAPIKey: PurchaseConstants.apiKey)

        // Listen for customer info changes
        Purchases.shared.delegate = self

        // Initial check
        Task {
            await checkProStatus()
            await loadOfferings()
        }
    }

    // MARK: - Load Offerings

    func loadOfferings() async {
        do {
            self.offerings = try await Purchases.shared.offerings()
            self.currentOffering = self.offerings?.current
        } catch {
            self.errorMessage = "Failed to load packages: \(error.localizedDescription)"
        }
    }

    // MARK: - Purchase

    func purchase(package: Package) async {
        isPurchasing = true
        errorMessage = nil

        do {
            let result = try await Purchases.shared.purchase(package: package)

            if !result.userCancelled {
                self.isProUser = result.customerInfo.entitlements[PurchaseConstants.proEntitlementID]?.isActive == true
                FirebaseConfig.logPurchaseCompleted(productId: package.storeProduct.productIdentifier)
            }
        } catch {
            self.errorMessage = "Purchase failed: \(error.localizedDescription)"
        }

        isPurchasing = false
    }

    // MARK: - Restore Purchases

    func restorePurchases() async {
        isRestoring = true
        errorMessage = nil

        do {
            let info = try await Purchases.shared.restorePurchases()
            self.isProUser = info.entitlements[PurchaseConstants.proEntitlementID]?.isActive == true

            if !isProUser {
                self.errorMessage = "No active subscription found."
            }
        } catch {
            self.errorMessage = "Restore failed: \(error.localizedDescription)"
        }

        isRestoring = false
    }

    // MARK: - Check Pro Status

    func checkProStatus() async {
        do {
            let info = try await Purchases.shared.customerInfo()
            self.isProUser = info.entitlements[PurchaseConstants.proEntitlementID]?.isActive == true
        } catch {
            // Silently fail — user remains non-pro
        }
    }
}

// MARK: - PurchasesDelegate

extension PurchaseManager: PurchasesDelegate {
    nonisolated func purchases(_ purchases: Purchases,
                               receivedUpdated customerInfo: CustomerInfo) {
        Task { @MainActor in
            self.isProUser = customerInfo.entitlements[PurchaseConstants.proEntitlementID]?.isActive == true
        }
    }
}
