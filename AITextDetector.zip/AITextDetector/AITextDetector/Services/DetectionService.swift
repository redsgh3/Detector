import Foundation

enum NetworkError: LocalizedError {
    case invalidURL
    case invalidResponse
    case serverError(Int)
    case decodingError
    case noData
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid URL"
        case .invalidResponse: return "Invalid server response"
        case .serverError(let code): return "Server error (code: \(code))"
        case .decodingError: return "Failed to parse response"
        case .noData: return "No data received"
        case .unknown(let error): return error.localizedDescription
        }
    }
}

protocol DetectionServiceProtocol {
    func detectAI(text: String) async throws -> DetectionResponse
}

final class DetectionService: DetectionServiceProtocol {

    private let session: URLSession

    init(session: URLSession = .shared) {
        self.session = session
    }

    func detectAI(text: String) async throws -> DetectionResponse {
        guard let url = URL(string: APIConfig.baseURL) else {
            throw NetworkError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(APIConfig.apiKey, forHTTPHeaderField: "X-API-Key")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 30

        let body = DetectionRequest(text: text)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw NetworkError.unknown(error)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw NetworkError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            throw NetworkError.serverError(httpResponse.statusCode)
        }

        do {
            let apiResponse = try JSONDecoder().decode(APIResponse.self, from: data)
            return DetectionResponse(from: apiResponse)
        } catch {
            throw NetworkError.decodingError
        }
    }
}
