import SwiftUI
import RevenueCat

struct PaywallView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var purchaseManager = PurchaseManager.shared

    @State private var selectedPlan: PlanType = .yearly
    @State private var animateRings = false

    enum PlanType {
        case yearly, weekly
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                // Top bar
                topBar

                Spacer(minLength: 0)

                // Hero
                heroSection

                Spacer(minLength: 8)

                // Title
                titleSection

                Spacer(minLength: 12)

                // Features
                featuresSection
                    .padding(.horizontal, 24)

                Spacer(minLength: 14)

                // Package cards
                packagesSection
                    .padding(.horizontal, 24)

                Spacer(minLength: 10)

                // Cancel anytime
                cancelAnytimeLabel

                Spacer(minLength: 10)

                // Continue + footer (pinned at bottom)
                VStack(spacing: 10) {
                    errorSection
                    continueButton
                    footerLinks
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 6)
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 1.2)) {
                animateRings = true
            }
        }
        .task {
            if purchaseManager.currentOffering == nil {
                await purchaseManager.loadOfferings()
            }
        }
    }

    // MARK: - Top Bar

    private var topBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                Image(systemName: "xmark")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.white.opacity(0.6))
            }

            Spacer()

            Button(action: {
                Task { await purchaseManager.restorePurchases() }
            }) {
                if purchaseManager.isRestoring {
                    ProgressView()
                        .tint(.white.opacity(0.5))
                } else {
                    Text("Restore")
                        .font(.system(size: 15))
                        .foregroundStyle(.white.opacity(0.5))
                }
            }
            .disabled(purchaseManager.isRestoring)
        }
        .padding(.horizontal, 24)
        .padding(.top, 10)
    }

    // MARK: - Hero (concentric rings + AI badge)

    private var heroSection: some View {
        ZStack {
            ForEach(0..<4, id: \.self) { i in
                Circle()
                    .stroke(Color.white.opacity(0.04 + Double(i) * 0.02), lineWidth: 1)
                    .frame(width: CGFloat(180 - i * 36), height: CGFloat(180 - i * 36))
                    .scaleEffect(animateRings ? 1.0 : 0.8)
                    .opacity(animateRings ? 1.0 : 0.0)
                    .animation(.easeOut(duration: 0.8).delay(Double(i) * 0.15), value: animateRings)
            }

            ZStack {
                Circle()
                    .fill(Color("AccentGreen").opacity(0.15))
                    .frame(width: 66, height: 66)

                Circle()
                    .fill(Color("AccentGreen"))
                    .frame(width: 50, height: 50)

                Text("AI")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
            }

            Image(systemName: "magnifyingglass")
                .font(.system(size: 30, weight: .light))
                .foregroundStyle(.white.opacity(0.5))
                .offset(x: 16, y: 10)

            Image(systemName: "sparkle")
                .font(.system(size: 10))
                .foregroundStyle(.white.opacity(0.6))
                .offset(x: -35, y: -60)

            Image(systemName: "sparkle")
                .font(.system(size: 7))
                .foregroundStyle(.white.opacity(0.4))
                .offset(x: -22, y: -48)

            Image(systemName: "sparkle")
                .font(.system(size: 9))
                .foregroundStyle(.white.opacity(0.5))
                .offset(x: 42, y: -25)
        }
        .frame(height: 170)
    }

    // MARK: - Title

    private var titleSection: some View {
        VStack(spacing: 2) {
            HStack(spacing: 7) {
                Text("Get Pro")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundStyle(.white)
                Text("Access")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundStyle(Color("AccentGreen"))
            }
            HStack(spacing: 7) {
                Text("Go")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundStyle(.white)
                Text("Unlimited")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundStyle(Color("AccentGreen"))
            }
        }
    }

    // MARK: - Features

    private var featuresSection: some View {
        VStack(spacing: 12) {
            PaywallFeatureRow(iconName: "infinity", iconBgColor: .blue,
                              text: "Unlimited Access To All Features")
            PaywallFeatureRow(iconName: "person.2.fill", iconBgColor: .green,
                              text: "Make Text Sounds Naturally Human")
            PaywallFeatureRow(iconName: "circle.slash", iconBgColor: .purple,
                              text: "See If Your Text Was Written By AI")
            PaywallFeatureRow(iconName: "rectangle.badge.xmark", iconBgColor: .pink,
                              text: "Ad-Free Experience")
        }
    }

    // MARK: - Packages

    private var packagesSection: some View {
        VStack(spacing: 8) {
            yearlyCard
            weeklyCard
        }
    }

    private var yearlyCard: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) { selectedPlan = .yearly }
        }) {
            ZStack(alignment: .topTrailing) {
                HStack(spacing: 12) {
                    Image(systemName: selectedPlan == .yearly ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 22))
                        .foregroundStyle(selectedPlan == .yearly ? Color("AccentGreen") : .white.opacity(0.3))

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Unlimited Yearly")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white)
                        Text("Just $39.99 per year")
                            .font(.system(size: 12))
                            .foregroundStyle(.white.opacity(0.5))
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 1) {
                        Text("$0.77")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Per week")
                            .font(.system(size: 11))
                            .foregroundStyle(.white.opacity(0.4))
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 13)
                .background(
                    RoundedRectangle(cornerRadius: 14)
                        .fill(Color.white.opacity(0.06))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(selectedPlan == .yearly ? Color("AccentGreen") : .clear, lineWidth: 1.5)
                        )
                )

                Text("Best Offer!")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(Color("AccentGreen").opacity(0.7))
                    .clipShape(Capsule())
                    .offset(x: -10, y: -9)
            }
        }
    }

    private var weeklyCard: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) { selectedPlan = .weekly }
        }) {
            HStack(spacing: 12) {
                Image(systemName: selectedPlan == .weekly ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 22))
                    .foregroundStyle(selectedPlan == .weekly ? Color("AccentGreen") : .white.opacity(0.3))

                Text("Unlimited Weekly")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)

                Spacer()

                VStack(alignment: .trailing, spacing: 1) {
                    Text("$6.99")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Per week")
                        .font(.system(size: 11))
                        .foregroundStyle(.white.opacity(0.4))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 13)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color.white.opacity(0.06))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(selectedPlan == .weekly ? Color("AccentGreen") : .clear, lineWidth: 1.5)
                    )
            )
        }
    }

    // MARK: - Cancel Anytime

    private var cancelAnytimeLabel: some View {
        HStack(spacing: 5) {
            Image(systemName: "checkmark.shield.fill")
                .font(.system(size: 13))
                .foregroundStyle(Color("AccentGreen"))
            Text("Cancel anytime")
                .font(.system(size: 13))
                .foregroundStyle(Color("AccentGreen"))
        }
    }

    // MARK: - Continue Button

    private var continueButton: some View {
        Button(action: {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
            FirebaseConfig.logProTapped(source: "paywall")

            if let offering = purchaseManager.currentOffering {
                let pkg: Package?
                switch selectedPlan {
                case .yearly:
                    pkg = offering.annual ?? offering.availablePackages.first
                case .weekly:
                    pkg = offering.weekly ?? offering.availablePackages.last
                }
                if let pkg = pkg {
                    Task { await purchaseManager.purchase(package: pkg) }
                }
            }
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color("AccentGreen"))
                    .frame(height: 52)

                if purchaseManager.isPurchasing {
                    ProgressView()
                        .tint(.white)
                } else {
                    Text("Continue")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white)
                }
            }
        }
        .disabled(purchaseManager.isPurchasing)
    }

    // MARK: - Error

    @ViewBuilder
    private var errorSection: some View {
        if let error = purchaseManager.errorMessage {
            Text(error)
                .font(.system(size: 11))
                .foregroundStyle(.red.opacity(0.8))
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
    }

    // MARK: - Footer

    private var footerLinks: some View {
        HStack {
            HStack(spacing: 4) {
                Button("Terms") {}
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.4))
                Text("•")
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.3))
                Button("Privacy") {}
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.4))
            }
            Spacer()
            Text("Cancel Anytime")
                .font(.system(size: 12))
                .foregroundStyle(.white.opacity(0.4))
        }
    }
}

// MARK: - Feature Row

private struct PaywallFeatureRow: View {
    let iconName: String
    let iconBgColor: Color
    let text: String

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(iconBgColor.opacity(0.2))
                    .frame(width: 32, height: 32)

                Image(systemName: iconName)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(iconBgColor)
            }

            Text(text)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.white)

            Spacer()
        }
    }
}

#Preview {
    PaywallView()
        .preferredColorScheme(.dark)
}
