import SwiftUI

struct DetectorView: View {
    @StateObject private var viewModel = DetectorViewModel()
    @EnvironmentObject private var purchaseManager: PurchaseManager
    @FocusState private var isTextEditorFocused: Bool
    @State private var showPaywall = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 0) {
                    ScrollView {
                        VStack(spacing: 20) {
                            textInputSection
                            errorSection
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 12)
                    }

                    Spacer()

                    detectButton
                        .padding(.horizontal, 20)
                        .padding(.bottom, 16)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("AI Detector")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {}) {
                        Image(systemName: "gearshape.fill")
                            .foregroundStyle(.white.opacity(0.7))
                            .font(.system(size: 18))
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    goProButton
                }
            }
            .onTapGesture {
                isTextEditorFocused = false
            }
            .fullScreenCover(isPresented: $viewModel.showResults) {
                if let result = viewModel.result {
                    ResultsView(result: result) {
                        viewModel.dismissResults()
                    }
                    .environmentObject(purchaseManager)
                }
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
            .onAppear {
                FirebaseConfig.logScreenView("detector")
            }
        }
    }

    // MARK: - Text Input Section

    private var textInputSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topLeading) {
                // Background card
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.white.opacity(0.06))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    )

                VStack {
                    // Text editor
                    ZStack(alignment: .topLeading) {
                        if viewModel.inputText.isEmpty {
                            Text("Enter text to analyze if it's AI-Generated...")
                                .foregroundStyle(.white.opacity(0.35))
                                .font(.system(size: 16))
                                .padding(.top, 18)
                                .padding(.leading, 16)
                        }

                        TextEditor(text: $viewModel.inputText)
                            .focused($isTextEditorFocused)
                            .font(.system(size: 16))
                            .foregroundStyle(.white)
                            .scrollContentBackground(.hidden)
                            .padding(.horizontal, 12)
                            .padding(.top, 10)
                    }

                    // Bottom bar: character count + paste/clear
                    HStack {
                        Text("\(viewModel.characterCount) characters")
                            .font(.system(size: 12))
                            .foregroundStyle(.white.opacity(0.35))

                        Spacer()

                        if !viewModel.inputText.isEmpty {
                            Button(action: { viewModel.clearText() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 13))
                                    Text("Clear")
                                        .font(.system(size: 13, weight: .medium))
                                }
                                .foregroundStyle(.white.opacity(0.5))
                            }
                        }

                        Button(action: pasteFromClipboard) {
                            HStack(spacing: 4) {
                                Image(systemName: "doc.on.clipboard.fill")
                                    .font(.system(size: 13))
                                Text("Paste")
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color("AccentGreen"))
                            .foregroundStyle(.white)
                            .clipShape(Capsule())
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)
                }
            }
            .frame(height: 260)
        }
    }

    // MARK: - Error Section

    @ViewBuilder
    private var errorSection: some View {
        if let error = viewModel.errorMessage {
            HStack(spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(.red)
                Text(error)
                    .font(.system(size: 14))
                    .foregroundStyle(.red.opacity(0.9))
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.red.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    // MARK: - Detect Button

    private var detectButton: some View {
        Button(action: { viewModel.detectAI() }) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(viewModel.isInputEmpty
                          ? Color.white.opacity(0.06)
                          : Color("AccentGreen"))
                    .frame(height: 54)

                if viewModel.isLoading {
                    ProgressView()
                        .tint(.white)
                } else {
                    Text("Detect AI")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(viewModel.isInputEmpty
                                         ? .white.opacity(0.3)
                                         : .white)
                }
            }
        }
        .disabled(viewModel.isInputEmpty || viewModel.isLoading)
    }

    // MARK: - Go Pro Button

    private var goProButton: some View {
        Group {
            if !purchaseManager.isProUser {
                Button(action: {
                    FirebaseConfig.logProTapped(source: "detector_nav")
                    showPaywall = true
                }) {
                    HStack(spacing: 4) {
                        Text("Go Pro")
                            .font(.system(size: 13, weight: .semibold))
                        Image(systemName: "sparkles")
                            .font(.system(size: 11))
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color("AccentGreen"))
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
                }
            }
        }
    }

    // MARK: - Paste

    private func pasteFromClipboard() {
        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.impactOccurred()
        if let text = UIPasteboard.general.string {
            viewModel.inputText = text
        }
    }
}

#Preview {
    DetectorView()
        .preferredColorScheme(.dark)
}
