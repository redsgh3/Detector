import SwiftUI

struct ResultsView: View {
    let result: DetectionResult
    let onDismiss: () -> Void

    @EnvironmentObject private var purchaseManager: PurchaseManager
    @State private var animateGauge = false
    @State private var animateBars = false
    @State private var showPaywall = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                ScrollView {
                    // Single dark card wrapping all content
                    VStack(spacing: 24) {
                        // Detection Result heading
                        Text("Detection Result")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.top, 4)

                        // Gauge
                        GaugeView(percentage: result.aiPercentage, animate: animateGauge)
                            .frame(height: 220)

                        // Label below gauge
                        Text(result.label)
                            .font(.system(size: 15))
                            .foregroundStyle(.white.opacity(0.6))
                            .padding(.top, -12)

                        // Analysis Details heading
                        Text("Analysis Details")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.top, 4)

                        // Bar rows with dividers
                        VStack(spacing: 0) {
                            AnalysisBarRow(
                                percentage: result.aiPercentage,
                                label: "AI Generated",
                                color: .red,
                                animate: animateBars
                            )

                            Divider().background(Color.white.opacity(0.1)).padding(.vertical, 12)

                            AnalysisBarRow(
                                percentage: result.humanPercentage,
                                label: "Human Writing",
                                color: Color("AccentGreen"),
                                animate: animateBars
                            )

                            Divider().background(Color.white.opacity(0.1)).padding(.vertical, 12)

                            AnalysisBarRow(
                                percentage: result.mixedPercentage,
                                label: "Mixed Content",
                                color: .yellow,
                                animate: animateBars
                            )
                        }

                        // Summary card (darker inside the main card)
                        Text(result.summary)
                            .font(.system(size: 15))
                            .foregroundStyle(.white.opacity(0.8))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 18)
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.05))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 24)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white.opacity(0.06))
                    )
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 40)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("AI Detector")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: onDismiss) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    goProButton
                }
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
        }
        .onAppear {
            FirebaseConfig.logScreenView("results")
            FirebaseConfig.logDetection(aiPercentage: result.aiPercentage)

            withAnimation(.easeOut(duration: 1.0)) {
                animateGauge = true
            }
            withAnimation(.easeOut(duration: 0.8).delay(0.5)) {
                animateBars = true
            }
        }
    }

    private var goProButton: some View {
        Group {
            if !purchaseManager.isProUser {
                Button(action: {
                    FirebaseConfig.logProTapped(source: "results_nav")
                    showPaywall = true
                }) {
                    HStack(spacing: 4) {
                        Text("Go Pro")
                            .font(.system(size: 13, weight: .semibold))
                        Image(systemName: "sparkles")
                            .font(.system(size: 11))
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color("AccentGreen"))
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
                }
            }
        }
    }
}
