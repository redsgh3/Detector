import SwiftUI

struct GaugeView: View {
    let percentage: Int
    let animate: Bool

    // Arc spans from 150° to 390° (240° total sweep)
    private let startAngle: Double = 150
    private let endAngle: Double = 390

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let center = CGPoint(x: geo.size.width / 2, y: size * 0.52)
            let radius = size * 0.38

            ZStack {
                // Background arc track
                GaugeArcBackground(center: center, radius: radius, startAngle: startAngle, endAngle: endAngle)

                // Colored gradient arc
                GaugeArcForeground(
                    center: center,
                    radius: radius,
                    startAngle: startAngle,
                    endAngle: endAngle,
                    percentage: percentage,
                    animate: animate
                )

                // Center percentage label
                GaugeLabel(percentage: percentage, animate: animate)
                    .position(x: center.x, y: center.y + 8)
            }
        }
    }
}

// MARK: - Background arc

private struct GaugeArcBackground: View {
    let center: CGPoint
    let radius: CGFloat
    let startAngle: Double
    let endAngle: Double

    var body: some View {
        GaugeArcShape(center: center, radius: radius, startAngle: startAngle, endAngle: endAngle)
            .stroke(Color.white.opacity(0.08), style: StrokeStyle(lineWidth: 28, lineCap: .round))
    }
}

// MARK: - Gradient foreground arc

private struct GaugeArcForeground: View {
    let center: CGPoint
    let radius: CGFloat
    let startAngle: Double
    let endAngle: Double
    let percentage: Int
    let animate: Bool

    var body: some View {
        GaugeArcShape(center: center, radius: radius, startAngle: startAngle, endAngle: endAngle)
            .trim(from: 0, to: animate ? Double(percentage) / 100.0 : 0)
            .stroke(
                AngularGradient(
                    colors: [.green, .green, .yellow, .orange, .red],
                    center: UnitPoint(x: 0.5, y: 0.52),
                    startAngle: .degrees(startAngle),
                    endAngle: .degrees(endAngle)
                ),
                style: StrokeStyle(lineWidth: 28, lineCap: .round)
            )
    }
}

// MARK: - Tick marks (outside the arc, near the end region)

private struct GaugeTickMarks: View {
    let center: CGPoint
    let radius: CGFloat
    let startAngle: Double
    let endAngle: Double

    var body: some View {
        // Ticks only in the last ~30% of the arc (right side)
        let tickStartFraction = 0.7
        let tickCount = 8

        ForEach(0..<tickCount, id: \.self) { i in
            let fraction = tickStartFraction + (1.0 - tickStartFraction) * Double(i) / Double(tickCount - 1)
            let angle = startAngle + (endAngle - startAngle) * fraction
            let rad = angle * .pi / 180
            let innerR = radius + 16
            let outerR = radius + 26
            let isMajor = (i == 0 || i == tickCount - 1)

            Path { path in
                path.move(to: CGPoint(
                    x: center.x + innerR * cos(rad),
                    y: center.y + innerR * sin(rad)
                ))
                path.addLine(to: CGPoint(
                    x: center.x + outerR * cos(rad),
                    y: center.y + outerR * sin(rad)
                ))
            }
            .stroke(Color.white.opacity(isMajor ? 0.35 : 0.15), lineWidth: isMajor ? 2 : 1)
        }
    }
}

// MARK: - Short needle at arc edge

private struct GaugeNeedle: View {
    let center: CGPoint
    let radius: CGFloat
    let startAngle: Double
    let endAngle: Double
    let percentage: Int

    private var currentAngle: Double {
        startAngle + (endAngle - startAngle) * Double(percentage) / 100.0
    }

    var body: some View {
        let rad = currentAngle * .pi / 180
        let innerR = radius - 6
        let outerR = radius + 30

        ZStack {
            // Needle line (short, from just inside the arc to just outside)
            Path { path in
                path.move(to: CGPoint(
                    x: center.x + innerR * cos(rad),
                    y: center.y + innerR * sin(rad)
                ))
                path.addLine(to: CGPoint(
                    x: center.x + outerR * cos(rad),
                    y: center.y + outerR * sin(rad)
                ))
            }
            .stroke(Color.white, style: StrokeStyle(lineWidth: 3, lineCap: .round))

            // Needle tip dot
            Circle()
                .fill(Color.white)
                .frame(width: 8, height: 8)
                .position(
                    x: center.x + outerR * cos(rad),
                    y: center.y + outerR * sin(rad)
                )
        }
    }
}

// MARK: - Center label

private struct GaugeLabel: View {
    let percentage: Int
    let animate: Bool

    var body: some View {
        VStack(spacing: 0) {
            Text("\(animate ? percentage : 0)%")
                .font(.system(size: 48, weight: .bold))
                .foregroundStyle(.white)
                .contentTransition(.numericText())

            Text("AI")
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(.white.opacity(0.8))
        }
    }
}

// MARK: - Arc Shape

private struct GaugeArcShape: Shape {
    let center: CGPoint
    let radius: CGFloat
    let startAngle: Double
    let endAngle: Double

    func path(in rect: CGRect) -> Path {
        Path { path in
            path.addArc(
                center: center,
                radius: radius,
                startAngle: .degrees(startAngle),
                endAngle: .degrees(endAngle),
                clockwise: false
            )
        }
    }
}
