import SwiftUI

struct AnalysisBarRow: View {
    let percentage: Int
    let label: String
    let color: Color
    let animate: Bool

    var body: some View {
        VStack(spacing: 6) {
            HStack(alignment: .bottom) {
                Text("\(percentage)%")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(.white)

                Spacer()

                Text(label)
                    .font(.system(size: 14))
                    .foregroundStyle(.white.opacity(0.6))
            }

            // Progress bar
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.white.opacity(0.08))
                        .frame(height: 5)

                    RoundedRectangle(cornerRadius: 3)
                        .fill(color)
                        .frame(
                            width: animate
                                ? geo.size.width * CGFloat(percentage) / 100.0
                                : 0,
                            height: 5
                        )
                }
            }
            .frame(height: 5)
        }
    }
}
