import SwiftUI

struct MainTabView: View {
    @State private var selectedTab = 1

    var body: some View {
        TabView(selection: $selectedTab) {
            PlaceholderView(title: "Humanize", icon: "person.2.wave.2")
                .tabItem {
                    Image(systemName: "person.2.wave.2")
                    Text("Humanize")
                }
                .tag(0)

            DetectorView()
                .tabItem {
                    Image(systemName: "desktopcomputer")
                    Text("AI Detector")
                }
                .tag(1)

            PlaceholderView(title: "History", icon: "clock")
                .tabItem {
                    Image(systemName: "clock")
                    Text("History")
                }
                .tag(2)
        }
        .tint(Color("AccentGreen"))
    }
}

// Placeholder for non-primary tabs
struct PlaceholderView: View {
    let title: String
    let icon: String

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundStyle(.secondary)
            Text(title)
                .font(.title2)
                .foregroundStyle(.secondary)
            Text("Coming soon")
                .font(.subheadline)
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
    }
}
