import SwiftUI
import FirebaseCore

@main
struct AITextDetectorApp: App {

    @StateObject private var purchaseManager = PurchaseManager.shared

    init() {
        // Configure Firebase
        FirebaseConfig.configure()

        // Configure RevenueCat
        PurchaseManager.shared.configure()
    }

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .preferredColorScheme(.dark)
                .environmentObject(purchaseManager)
        }
    }
}
